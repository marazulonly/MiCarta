import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Store, 
  Clock, 
  ArrowUpRight, 
  ExternalLink,
  ChevronRight,
  Shield,
  Building2,
  BarChart3
} from 'lucide-react';
import { Restaurant, Order, UserRole, User, MenuTemplate, MenuItem, MenuCategory } from '../types';
import { AdminDashboard } from './AdminDashboard';
import { OwnerDashboard } from './OwnerDashboard';

interface HomeViewProps {
  currentUser?: User | null;
  restaurants: Restaurant[];
  orders: Order[];
  users: User[];
  templates: MenuTemplate[];
  categories?: MenuCategory[];
  menuItems?: MenuItem[];
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onNavigateToRestaurants: () => void;
  onNavigateToOrders: () => void;
  onOpenCustomerPreview: (restaurant: Restaurant, mode?: 'DINE_IN' | 'DELIVERY') => void;
  onUpdateRestaurant: (updated: Restaurant) => void;
  onAddRestaurant?: (newRestaurant: Restaurant) => void;
  onDeleteRestaurant?: (restaurantId: string) => void;
  onUpdateUser: (updated: User) => void;
  onAddUser?: (newUser: User) => void;
  onDeleteUser?: (userId: string) => void;
  onUpdateTemplate: (updated: MenuTemplate) => void;
  onDeleteTemplate?: (templateId: string) => void;
  onAddMenuItem?: (newItem: MenuItem) => void;
  onUpdateMenuItem?: (updatedItem: MenuItem) => void;
  onDeleteMenuItem?: (itemId: string) => void;
  onAddCategory?: (newCategory: MenuCategory) => void;
  onUpdateCategory?: (updatedCategory: MenuCategory) => void;
  onDeleteCategory?: (categoryId: string) => void;
  onImportBackupJSON?: (
    data: { restaurants: Restaurant[]; categories: MenuCategory[]; items: MenuItem[] },
    mode?: any,
    targetRestaurantId?: string
  ) => void;
  onPublishMenu?: (
    restaurantId: string,
    restaurant: Restaurant,
    categories: MenuCategory[],
    items: MenuItem[]
  ) => Promise<{ success: boolean; version?: number; publishedAt?: string } | void> | void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  currentUser,
  restaurants,
  orders,
  users,
  templates,
  categories = [],
  menuItems = [],
  activeRole,
  onRoleChange,
  onNavigateToRestaurants,
  onNavigateToOrders,
  onOpenCustomerPreview,
  onUpdateRestaurant,
  onAddRestaurant,
  onDeleteRestaurant,
  onUpdateUser,
  onAddUser,
  onDeleteUser,
  onUpdateTemplate,
  onDeleteTemplate,
  onAddMenuItem,
  onUpdateMenuItem,
  onDeleteMenuItem,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onImportBackupJSON,
  onPublishMenu,
}) => {
  // Determine view mode based on activeRole or manual user toggle
  const [viewMode, setViewMode] = useState<'admin' | 'owner' | 'overview'>(
    activeRole === 'OWNER' ? 'owner' : 'admin'
  );

  // Keep viewMode synced if activeRole changes from the header dropdown
  useEffect(() => {
    if (activeRole === 'OWNER') {
      setViewMode('owner');
    } else if (activeRole === 'ADMIN') {
      setViewMode('admin');
    }
  }, [activeRole]);

  const safeRests = (restaurants || []).filter(Boolean);
  const safeOrds = (orders || []).filter(Boolean);
  const totalRevenue = safeRests.reduce((acc, r) => acc + (r?.metrics?.dailyRevenue || 0), 0);
  const activeOrdersCount = safeOrds.filter(o => o?.status !== 'DELIVERED' && o?.status !== 'CANCELLED').length;
  const avgOccupancy = safeRests.length > 0
    ? Math.round(safeRests.reduce((acc, r) => acc + (r?.metrics?.occupancyRate || 0), 0) / safeRests.length)
    : 0;

  return (
    <div className="space-y-6">
      
      {/* Top View Switcher Pills */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-neutral-200/50">
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white border border-neutral-200/60 shadow-sm">
          <button
            onClick={() => {
              setViewMode('admin');
              onRoleChange('ADMIN');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewMode === 'admin'
                ? 'bg-[#1E1F24] text-white shadow-sm'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Vista de Administrador</span>
          </button>

          <button
            onClick={() => {
              setViewMode('owner');
              onRoleChange('OWNER');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewMode === 'owner'
                ? 'bg-[#1E1F24] text-white shadow-sm'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Vista de Dueños</span>
          </button>

          <button
            onClick={() => setViewMode('overview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewMode === 'overview'
                ? 'bg-[#1E1F24] text-white shadow-sm'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Resumen Financiero</span>
          </button>
        </div>

        <div className="text-[11px] text-neutral-500 font-mono">
          Modo actual: <strong className="text-[#1E1F24] uppercase font-bold">{viewMode}</strong>
        </div>
      </div>

      {/* Render Admin Dashboard */}
      {viewMode === 'admin' && (
        <AdminDashboard
          restaurants={restaurants}
          users={users}
          templates={templates}
          onUpdateRestaurant={onUpdateRestaurant}
          onAddRestaurant={onAddRestaurant}
          onDeleteRestaurant={onDeleteRestaurant}
          onUpdateUser={onUpdateUser}
          onAddUser={onAddUser || (() => {})}
          onDeleteUser={onDeleteUser}
          onUpdateTemplate={onUpdateTemplate}
          onDeleteTemplate={onDeleteTemplate}
          onOpenCustomerPreview={onOpenCustomerPreview}
          onSwitchToOwnerView={() => {
            setViewMode('owner');
            onRoleChange('OWNER');
          }}
        />
      )}

      {/* Render Owner Dashboard */}
      {viewMode === 'owner' && (
        <OwnerDashboard
          currentUser={currentUser || undefined}
          restaurants={restaurants}
          users={users}
          templates={templates}
          menuItems={menuItems}
          categories={categories}
          onUpdateRestaurant={onUpdateRestaurant}
          onAddRestaurant={onAddRestaurant}
          onDeleteRestaurant={onDeleteRestaurant}
          onAddUser={onAddUser}
          onUpdateUser={onUpdateUser}
          onAddMenuItem={onAddMenuItem}
          onUpdateMenuItem={onUpdateMenuItem}
          onDeleteMenuItem={onDeleteMenuItem}
          onAddCategory={onAddCategory}
          onUpdateCategory={onUpdateCategory}
          onDeleteCategory={onDeleteCategory}
          onOpenCustomerPreview={onOpenCustomerPreview}
          onImportBackupJSON={onImportBackupJSON}
          onPublishMenu={onPublishMenu}
          onSwitchToAdminView={() => {
            setViewMode('admin');
            onRoleChange('ADMIN');
          }}
        />
      )}

      {/* Render General Financial Overview */}
      {viewMode === 'overview' && (
        <div className="space-y-6 pb-28">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-200 pb-5">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-neutral-950">
                Resumen Financiero y Comandas
              </h1>
              <p className="text-xs text-neutral-600 mt-1">
                Supervisión general de los 4 locales, enlaces públicos y comandas activas.
              </p>
            </div>

            <button
              onClick={onNavigateToOrders}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-neutral-900 border border-neutral-300 shadow-sm font-bold text-xs hover:bg-neutral-100 transition cursor-pointer self-start sm:self-auto"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-neutral-700" />
              <span>Comandas Activas ({activeOrdersCount})</span>
            </button>
          </div>

          {/* Minimalist 4-Metric Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-5 rounded-2xl border border-neutral-200 bg-white shadow-xs hover:border-neutral-300 transition">
              <div className="flex items-center justify-between text-neutral-500">
                <span className="text-xs font-bold text-neutral-600">Facturación Diaria</span>
                <DollarSign className="w-4 h-4 text-neutral-500" />
              </div>
              <div className="mt-3">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-neutral-900">
                  ${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-[11px] text-neutral-500 font-medium block mt-1">
                  En los 4 locales hoy
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-neutral-200 bg-white shadow-xs hover:border-neutral-300 transition">
              <div className="flex items-center justify-between text-neutral-500">
                <span className="text-xs font-bold text-neutral-600">Comandas Activas</span>
                <ShoppingBag className="w-4 h-4 text-neutral-500" />
              </div>
              <div className="mt-3">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-neutral-900">
                  {activeOrdersCount}
                </span>
                <span className="text-[11px] text-neutral-500 font-medium block mt-1">
                  En salón y delivery
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-neutral-200 bg-white shadow-xs hover:border-neutral-300 transition">
              <div className="flex items-center justify-between text-neutral-500">
                <span className="text-xs font-bold text-neutral-600">Ocupación Media</span>
                <Store className="w-4 h-4 text-neutral-500" />
              </div>
              <div className="mt-3">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-neutral-900">
                  {avgOccupancy}%
                </span>
                <span className="text-[11px] text-neutral-500 font-medium block mt-1">
                  82 mesas disponibles en total
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-neutral-200 bg-white shadow-xs hover:border-neutral-300 transition">
              <div className="flex items-center justify-between text-neutral-500">
                <span className="text-xs font-bold text-neutral-600">Ticket Promedio</span>
                <TrendingUp className="w-4 h-4 text-neutral-500" />
              </div>
              <div className="mt-3">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-neutral-900">
                  $36.15
                </span>
                <span className="text-[11px] text-neutral-500 font-medium block mt-1">
                  +8.4% vs semana previa
                </span>
              </div>
            </div>
          </div>

          {/* Orders List */}
          <div className="p-5 sm:p-6 rounded-2xl border border-neutral-200 bg-white shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <h3 className="text-sm font-bold text-neutral-900">Comandas Recientes en Tiempo Real</h3>
              <button
                onClick={onNavigateToOrders}
                className="text-xs text-neutral-600 hover:text-neutral-900 font-bold flex items-center gap-1 cursor-pointer transition"
              >
                <span>Ver Tablero KDS</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-neutral-100">
              {(orders || []).filter(Boolean).slice(0, 4).map(order => {
                const rest = restaurants.find(r => r && r.id === order.restaurantId);
                return (
                  <div 
                    key={order.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-neutral-50/60 rounded-xl px-2 transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center font-mono font-bold text-xs text-white shrink-0 shadow-xs">
                        {order.orderNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-neutral-900">{order.customerName || 'Cliente'}</span>
                          <span className="text-[11px] text-neutral-500 font-mono">
                            ({rest?.name || 'Local'})
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-600 mt-0.5">
                          {(order.items || []).map(i => i ? `${i.quantity}x ${i.name}` : '').filter(Boolean).join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 text-xs">
                      <span className="font-bold text-neutral-900 font-mono text-sm">S/ {(order.total || 0).toFixed(2)}</span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-neutral-100 text-neutral-800 border border-neutral-300">
                        {order.status === 'PENDING' ? 'Pendiente' :
                         order.status === 'IN_KITCHEN' || (order.status as string) === 'PREPARING' ? 'En Cocina' :
                         order.status === 'READY' ? 'Listo' : 'Entregado'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
